package net.softsociety.spring2.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import net.softsociety.spring2.domain.Person;

@Controller
public class ParamController {
	//입력화면으로 이동
	@GetMapping("/param/test1")
	public String test1() {
		return "/paramView/view1";
	}
	
	//test1에서 전달한 parameter 받아서 처리
	@GetMapping("/param/input1")
	public String input1(String name, int age) {
		System.out.println(name);
		System.out.println(age);
		
		return "/paramView/view1";
	}
	
	//입력화면으로 이동
	@GetMapping("/param/test2")
	public String test2() {
		return "/paramView/view2";
	}
	
	//test2에서 전달한 parameter 받아서 처리
	@PostMapping("/param/input2")
	public String input2(String id, String password, String name, String phone, String com) {
		//폼에서 전달받은 ID ~ 전화번호까지 출력
		System.out.println("ID:" + id);
		System.out.println("Password:" + password);
		
		return "redirect:/";
	}
	
	//입력화면으로 이동
	@GetMapping("/param/test3")
	public String test3() {
		return "/paramView/view3";
	}
	
	//test3에서 전달한 parameter 받아서 처리
	@PostMapping("/param/input3")
	public String input3(Person p) {
		System.out.println(p);
		return "redirect:/";
	}
	
	//모델 사용
	@GetMapping("/param/model")
	public String model(Model model) {
		int num = 999;
		String str = "서버의 문자열";
		ArrayList<String> list = new ArrayList<>();
		list.add("aaa");
		list.add("bbb");
		list.add("ccc");
		Person p = new Person("aaa", "홍길동", "123", "010-2222-3333", "KT");
		
		model.addAttribute("number", num);
		model.addAttribute("str", str);
		model.addAttribute("list", list);
		model.addAttribute("person", p);
		
		return "/paramView/model";	//templates/paramView 폴더의 model.html로 포워딩
	}

}


