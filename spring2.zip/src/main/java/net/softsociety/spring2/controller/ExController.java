package net.softsociety.spring2.controller;

import java.util.Calendar;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

/**
 * 연습문제
 */
@Slf4j
@RequestMapping("/ex")
@Controller
public class ExController {
	
	/**
	 * 계산기 폼 화면으로 이동
	 * @return 계산기 폼 HTML 파일 경로
	 */
	@GetMapping("/test1")
	public String calc() {
		return "exView/calc";
	}
	
	/**
	 * 계산기 폼에서 입력한 값을 전달받아 계산하고 결과페이지로 포워딩
	 * @param model View로 값을 전달할 Model 객체
	 * @param op	연산자
	 * @param num1	피연산자1
	 * @param num2	피연산자2
	 * @return 결과 출력할 HTML 파일 경로
	 */
	@PostMapping("/calc")
	public String calc(String op, String num1, String num2, Model model) {
		log.debug("전달된 값: {}, {}, {}", op , num1, num2);

		int res = 0, n1, n2;
		try {
			n1 = Integer.parseInt(num1);
			n2 = Integer.parseInt(num2);
			
			switch (op) {
				case "+" : res = n1 + n2; break;
				case "-" : res = n1 - n2; break;
				case "*" : res = n1 * n2; break;
				case "/" : res = n1 / n2; break;
				default: throw new Exception("연산자 오류");
			}
			model.addAttribute("num1", num1);
			model.addAttribute("num2", num2);
			model.addAttribute("op", op);
			model.addAttribute("res", res);
		}
		catch (Exception e) {
			e.printStackTrace();
			return "/exview/calc";	//예외 발생시 계산폼으로 다시 이동
		}
		
		return "/exView/calcOutput";
	}

	/**
	 * 개인정보 입력폼으로 이동
	 * @return 입력폼 HTML 파일 경로
	 */
	@GetMapping("/test2")
	public String info() {
		return "exView/info";
	}
	
	/**
	 * 입력한 이름과 주민등록번호를 전달받아 처리 결과를 infoOutput.html에서 출력
	 * @param name	이름
	 * @param num	주민등록번호
	 * @param model
	 * @return 결과 출력 HTML 파일 경로
	 */
	@PostMapping("/info")
	public String info(String name, String num, Model model) {
		
		log.debug("전달된 값 : {}, {}", name, num);
		model.addAttribute("name", name);
		model.addAttribute("num", num);
		
		String gender = null;
		char ch;
		int y = 0, m = 0, d = 0, age = 0;
		boolean error = false;
		
		//현재 연도
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);
		
		//글자수
		if (num.length() != 14) {
			error = true;
		}
		//'-' 문자 확인
		if (num.indexOf('-') != 6) {
			error = true;
		}
		//성별
		ch = num.charAt(7);
		if ( ch < '1' || ch > '4') {
			error = true;
		}
		
		try {
			//생년월일
			y = Integer.parseInt(num.substring(0, 2));
			m = Integer.parseInt(num.substring(2, 4));
			d = Integer.parseInt(num.substring(4, 6));
			//성별
			gender = ch == '1' || ch == '3' ? "남자" : "여자";
			//나이
			if (ch == '1' || ch == '2') {
				age = year - y - 1900;
			}
			else {
				age = year - y - 2000;
			}
		}
		catch (Exception e) {
			error = true;
		}
		
		if (error) {
			model.addAttribute("error", "error");
			return "/exView/info";		//입력폼으로 포워딩
		}
		
		//model.addAttribute("y", num.substring(0, 2));	//문자열로 전달
		model.addAttribute("y", y);
		model.addAttribute("m", m);
		model.addAttribute("d", d);
		model.addAttribute("age", age);
		model.addAttribute("gender", gender);
		
		return "exView/infoOutput";
	}

	
	/**
	 * 방문횟수 카운트 예제
	 	방문횟수가 저장된 쿠키를 읽어온다
		없으면 방문횟수는 현재 0으로 처리
		있으면 쿠키에 저장된 숫자가 기존 방문횟수
		방문횟수에 1을 더한다
		쿠키에 증가된 방문횟수를 저장하여 클라이언트로 보낸다
		방문횟수를 Model에 저장하여 html페이지에서 환영 문구 출력 
	 * @param count 쿠키 이름으로 값 읽기
	 * @param response 응답 정보
	 * @param model 모델 객체
	 * @return	출력 HTML 파일 경로
	 */
	@GetMapping("/test3")
	public String cookie(
			@CookieValue(name="count", defaultValue="0") int count, 
			HttpServletResponse response, 
			Model model) {
		
		count++;
		model.addAttribute("count", count);

		Cookie cookie = new Cookie("count", Integer.toString(count));
		cookie.setMaxAge(60*60*24*365);
		response.addCookie(cookie);
		
		return "/exView/cookie";
	}
}
