package net.softsociety.spring2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

/**
 * spring2 예제의 메인 콘트롤러
 */
@Slf4j
@Controller
public class HomeController {

	/**
	 * http://localhost:8888/spring2로 요청시 홈 화면으로 이동
	 * @return templates 폴더의 home.html로 포워딩
	 */
	@GetMapping({"", "/"})
	public String home() {
		return "/home";
	}
	
	/**
	 * 로그 출력 테스트. application.properties에 설정한 레벨까지 로그 출력
	 * @return
	 */
	@GetMapping("/logtest")
	public String logtest() {
		String s = "변수의값";
		
		System.out.println("logtest 실행됨" + s);
		log.error("error");
		log.warn("warn");
		log.info("info 레벨의 출력");
		log.debug("디버깅 시 사용 : {}", s);
		
		return "redirect:/";
	}
}
